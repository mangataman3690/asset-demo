# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: localhost (MySQL 5.7.39)
# Database: iams
# Generation Time: 2023-05-10 23:45:13 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table asset_attachment
# ------------------------------------------------------------

DROP TABLE IF EXISTS `asset_attachment`;

CREATE TABLE `asset_attachment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `fileName` varchar(250) NOT NULL DEFAULT '',
  `storedFileName` varchar(250) NOT NULL DEFAULT '',
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `assetId` (`assetId`),
  CONSTRAINT `asset_attachment_ibfk_1` FOREIGN KEY (`assetId`) REFERENCES `assets` (`assetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table asset_history
# ------------------------------------------------------------

DROP TABLE IF EXISTS `asset_history`;

CREATE TABLE `asset_history` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `assetId` int(11) DEFAULT NULL,
  `changeHistory` text,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assetId` (`assetId`),
  KEY `userId` (`userId`),
  CONSTRAINT `asset_history_ibfk_1` FOREIGN KEY (`assetId`) REFERENCES `assets` (`assetId`),
  CONSTRAINT `asset_history_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `asset_history` WRITE;
/*!40000 ALTER TABLE `asset_history` DISABLE KEYS */;

INSERT INTO `asset_history` (`id`, `assetId`, `changeHistory`, `userId`)
VALUES
	(1,1,'A changed assetName from A Building to AA Building on 10-05-2023 19:35:03',1);

/*!40000 ALTER TABLE `asset_history` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table asset_user_map
# ------------------------------------------------------------

DROP TABLE IF EXISTS `asset_user_map`;

CREATE TABLE `asset_user_map` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `assetId` (`assetId`),
  KEY `userId` (`userId`),
  CONSTRAINT `asset_user_map_ibfk_1` FOREIGN KEY (`assetId`) REFERENCES `assets` (`assetId`),
  CONSTRAINT `asset_user_map_ibfk_2` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `asset_user_map` WRITE;
/*!40000 ALTER TABLE `asset_user_map` DISABLE KEYS */;

INSERT INTO `asset_user_map` (`id`, `assetId`, `userId`)
VALUES
	(1,1,2);

/*!40000 ALTER TABLE `asset_user_map` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table assets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `assets`;

CREATE TABLE `assets` (
  `assetId` int(11) NOT NULL AUTO_INCREMENT,
  `assetName` varchar(50) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `installationYear` int(11) NOT NULL DEFAULT '0',
  `expectedUsefulLife` int(11) NOT NULL DEFAULT '0',
  `renewalYear` int(11) NOT NULL DEFAULT '0',
  `assetCondition` text,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `unitCost` double DEFAULT NULL,
  `estimatedCost` double DEFAULT NULL,
  PRIMARY KEY (`assetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;

INSERT INTO `assets` (`assetId`, `assetName`, `description`, `installationYear`, `expectedUsefulLife`, `renewalYear`, `assetCondition`, `quantity`, `unitCost`, `estimatedCost`)
VALUES
	(1,'AA Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(2,'B Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(3,'C Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(4,'D Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(5,'E Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(6,'F Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(7,'G Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(8,'H Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921),
	(10,'J Building','3 Floor',2000,20,2019,'Well Managed',1,111222333,1678921);

/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table user_login_track
# ------------------------------------------------------------

DROP TABLE IF EXISTS `user_login_track`;

CREATE TABLE `user_login_track` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessDateTime` datetime NOT NULL,
  `deviceInfo` text,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`),
  CONSTRAINT `user_login_track_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `user_login_track` WRITE;
/*!40000 ALTER TABLE `user_login_track` DISABLE KEYS */;

INSERT INTO `user_login_track` (`id`, `userId`, `accessDateTime`, `deviceInfo`)
VALUES
	(1,1,'2023-05-10 19:30:59',''),
	(2,1,'2023-05-10 19:34:54','');

/*!40000 ALTER TABLE `user_login_track` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(50) NOT NULL DEFAULT '',
  `userPassword` varchar(50) NOT NULL DEFAULT '',
  `active` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0-inactive, 1-active',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;

INSERT INTO `users` (`userId`, `userName`, `userPassword`, `active`)
VALUES
	(1,'A','0cc175b9c0f1b6a831c399e269772661',1),
	(2,'B','0cc175b9c0f1b6a831c399e269772661',1),
	(3,'C','0cc175b9c0f1b6a831c399e269772661',1);

/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
